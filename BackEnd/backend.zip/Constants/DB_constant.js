export const DB_NAME = "automobile";
export const DB_USER = "root";
export const DB_PASS = "cdac";
export const DB_HOST = "localhost";
