export const Contact_Us_Table = "Contact_Us";
export const TABLE_F_NAME = "first_name";
export const TABLE_L_NAME = "last_name";
export const TABLE_EMAIL = "email";
export const TABLE_MESSAGE = "message";
export const TABLE_ID = "id";
export const Admin_Table = "admin";
export const SERVICE_TABLE_NAME = 'service';
