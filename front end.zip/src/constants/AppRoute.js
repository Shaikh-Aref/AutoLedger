export const BASE_ROUTE="/";
export const REGISTRATION_ROUTE="/register-customer";
export const CUSTOMER_LIST_ROUTE="/customer-list";
export const CUSTOMER_EDIT_ROUTE="/edit-customer/:Sr_No";
export const CONTACT_US = "/contact-us"
export const Log_In = "/admins/Log-in"
export const Sign_Up = '/admins/Sign-UP'
export const ABOUT_US = '/about_us'
