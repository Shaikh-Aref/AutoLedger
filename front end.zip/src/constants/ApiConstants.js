export const CUSTOMER_BASE_URL = 'http://127.0.0.1:9600';
export const SAVE_CUSTOMER_API_ROUTE = `${CUSTOMER_BASE_URL}/admin/service`;
export const GET_CUSTOMER_API_ROUTE = SAVE_CUSTOMER_API_ROUTE;
export const REMOVE_CUSTOMER_API_ROUTE = SAVE_CUSTOMER_API_ROUTE;
export const UPDATE_STUDENT_API_ROUTE = SAVE_CUSTOMER_API_ROUTE; 

export const CONTACT_US_BASE_URL = 'http://127.0.0.1:9600';
export const save_contact_us_route = `${CONTACT_US_BASE_URL}/aboutus/`
export const save_admin_login = `${CONTACT_US_BASE_URL}/admin`
export const fetch_admin_login = `${save_admin_login}/login`