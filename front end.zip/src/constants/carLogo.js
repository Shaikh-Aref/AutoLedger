export const logos = [
    { src: 'https://www.carlogos.org/car-logos/tesla-logo-2007-full-640.png', alt: 'Tesla' },
    { src: 'https://www.carlogos.org/car-logos/bmw-logo-2020-gray.png', alt: 'BMW' },
    { src: 'https://www.carlogos.org/car-logos/audi-logo-2016-640.png', alt: 'Audi' },
    { src: 'https://www.carlogos.org/car-logos/porsche-logo-2014-full-640.png', alt: 'Porche' },
    { src: 'https://www.carlogos.org/car-logos/jaguar-logo-2021-640.png', alt: 'Jaguar' },
    { src: 'https://www.carlogos.org/car-logos/honda-logo-2000-full-640.png', alt: 'Honda' }
  ];